/****************************************************************************
** Meta object code from reading C++ file 'appchat.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AppChatFinal/appchat.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'appchat.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSAppchatENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSAppchatENDCLASS = QtMocHelpers::stringData(
    "Appchat",
    "send_msg",
    "",
    "msg",
    "connect_enemy",
    "enemy",
    "start_app",
    "on_pushButton_start_clicked",
    "on_pushButton_connect_clicked",
    "on_pushButton_send_msg_clicked",
    "on_pushButton_back_clicked",
    "on_write_comboBox_list_connection",
    "on_write_textEdit_show_msg",
    "user",
    "on_tester",
    "str",
    "on_connect_next"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSAppchatENDCLASS_t {
    uint offsetsAndSizes[34];
    char stringdata0[8];
    char stringdata1[9];
    char stringdata2[1];
    char stringdata3[4];
    char stringdata4[14];
    char stringdata5[6];
    char stringdata6[10];
    char stringdata7[28];
    char stringdata8[30];
    char stringdata9[31];
    char stringdata10[27];
    char stringdata11[34];
    char stringdata12[27];
    char stringdata13[5];
    char stringdata14[10];
    char stringdata15[4];
    char stringdata16[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSAppchatENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSAppchatENDCLASS_t qt_meta_stringdata_CLASSAppchatENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7),  // "Appchat"
        QT_MOC_LITERAL(8, 8),  // "send_msg"
        QT_MOC_LITERAL(17, 0),  // ""
        QT_MOC_LITERAL(18, 3),  // "msg"
        QT_MOC_LITERAL(22, 13),  // "connect_enemy"
        QT_MOC_LITERAL(36, 5),  // "enemy"
        QT_MOC_LITERAL(42, 9),  // "start_app"
        QT_MOC_LITERAL(52, 27),  // "on_pushButton_start_clicked"
        QT_MOC_LITERAL(80, 29),  // "on_pushButton_connect_clicked"
        QT_MOC_LITERAL(110, 30),  // "on_pushButton_send_msg_clicked"
        QT_MOC_LITERAL(141, 26),  // "on_pushButton_back_clicked"
        QT_MOC_LITERAL(168, 33),  // "on_write_comboBox_list_connec..."
        QT_MOC_LITERAL(202, 26),  // "on_write_textEdit_show_msg"
        QT_MOC_LITERAL(229, 4),  // "user"
        QT_MOC_LITERAL(234, 9),  // "on_tester"
        QT_MOC_LITERAL(244, 3),  // "str"
        QT_MOC_LITERAL(248, 15)   // "on_connect_next"
    },
    "Appchat",
    "send_msg",
    "",
    "msg",
    "connect_enemy",
    "enemy",
    "start_app",
    "on_pushButton_start_clicked",
    "on_pushButton_connect_clicked",
    "on_pushButton_send_msg_clicked",
    "on_pushButton_back_clicked",
    "on_write_comboBox_list_connection",
    "on_write_textEdit_show_msg",
    "user",
    "on_tester",
    "str",
    "on_connect_next"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSAppchatENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   80,    2, 0x06,    1 /* Public */,
       4,    1,   83,    2, 0x06,    3 /* Public */,
       6,    0,   86,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    0,   87,    2, 0x08,    6 /* Private */,
       8,    0,   88,    2, 0x08,    7 /* Private */,
       9,    0,   89,    2, 0x08,    8 /* Private */,
      10,    0,   90,    2, 0x08,    9 /* Private */,
      11,    1,   91,    2, 0x08,   10 /* Private */,
      12,    2,   94,    2, 0x08,   12 /* Private */,
      14,    1,   99,    2, 0x08,   15 /* Private */,
      16,    0,  102,    2, 0x08,   17 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,   13,    3,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Appchat::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSAppchatENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSAppchatENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSAppchatENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Appchat, std::true_type>,
        // method 'send_msg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'connect_enemy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'start_app'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_start_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_connect_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_send_msg_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_back_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_write_comboBox_list_connection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_write_textEdit_show_msg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_tester'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_connect_next'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Appchat::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Appchat *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->send_msg((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->connect_enemy((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->start_app(); break;
        case 3: _t->on_pushButton_start_clicked(); break;
        case 4: _t->on_pushButton_connect_clicked(); break;
        case 5: _t->on_pushButton_send_msg_clicked(); break;
        case 6: _t->on_pushButton_back_clicked(); break;
        case 7: _t->on_write_comboBox_list_connection((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->on_write_textEdit_show_msg((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 9: _t->on_tester((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->on_connect_next(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Appchat::*)(QString );
            if (_t _q_method = &Appchat::send_msg; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Appchat::*)(QString );
            if (_t _q_method = &Appchat::connect_enemy; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Appchat::*)();
            if (_t _q_method = &Appchat::start_app; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *Appchat::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Appchat::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSAppchatENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Appchat::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void Appchat::send_msg(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Appchat::connect_enemy(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Appchat::start_app()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
