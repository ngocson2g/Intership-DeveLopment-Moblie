/****************************************************************************
** Meta object code from reading C++ file 'functionacction.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../AppChatFinal/functionacction.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'functionacction.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFunctionAcctionENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFunctionAcctionENDCLASS = QtMocHelpers::stringData(
    "FunctionAcction",
    "write_comboBox_list_connection",
    "",
    "enemy",
    "write_textEdit_show_msg",
    "user",
    "msg",
    "tester",
    "str",
    "connect_next",
    "on_send_msg",
    "on_connect_enemy",
    "on_start_app",
    "readData",
    "newConnection",
    "addConnection",
    "QTcpSocket*",
    "socket",
    "get_Address",
    "get_ListAddress_Server",
    "check_status_app",
    "connect_confirm"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFunctionAcctionENDCLASS_t {
    uint offsetsAndSizes[44];
    char stringdata0[16];
    char stringdata1[31];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[24];
    char stringdata5[5];
    char stringdata6[4];
    char stringdata7[7];
    char stringdata8[4];
    char stringdata9[13];
    char stringdata10[12];
    char stringdata11[17];
    char stringdata12[13];
    char stringdata13[9];
    char stringdata14[14];
    char stringdata15[14];
    char stringdata16[12];
    char stringdata17[7];
    char stringdata18[12];
    char stringdata19[23];
    char stringdata20[17];
    char stringdata21[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFunctionAcctionENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFunctionAcctionENDCLASS_t qt_meta_stringdata_CLASSFunctionAcctionENDCLASS = {
    {
        QT_MOC_LITERAL(0, 15),  // "FunctionAcction"
        QT_MOC_LITERAL(16, 30),  // "write_comboBox_list_connection"
        QT_MOC_LITERAL(47, 0),  // ""
        QT_MOC_LITERAL(48, 5),  // "enemy"
        QT_MOC_LITERAL(54, 23),  // "write_textEdit_show_msg"
        QT_MOC_LITERAL(78, 4),  // "user"
        QT_MOC_LITERAL(83, 3),  // "msg"
        QT_MOC_LITERAL(87, 6),  // "tester"
        QT_MOC_LITERAL(94, 3),  // "str"
        QT_MOC_LITERAL(98, 12),  // "connect_next"
        QT_MOC_LITERAL(111, 11),  // "on_send_msg"
        QT_MOC_LITERAL(123, 16),  // "on_connect_enemy"
        QT_MOC_LITERAL(140, 12),  // "on_start_app"
        QT_MOC_LITERAL(153, 8),  // "readData"
        QT_MOC_LITERAL(162, 13),  // "newConnection"
        QT_MOC_LITERAL(176, 13),  // "addConnection"
        QT_MOC_LITERAL(190, 11),  // "QTcpSocket*"
        QT_MOC_LITERAL(202, 6),  // "socket"
        QT_MOC_LITERAL(209, 11),  // "get_Address"
        QT_MOC_LITERAL(221, 22),  // "get_ListAddress_Server"
        QT_MOC_LITERAL(244, 16),  // "check_status_app"
        QT_MOC_LITERAL(261, 15)   // "connect_confirm"
    },
    "FunctionAcction",
    "write_comboBox_list_connection",
    "",
    "enemy",
    "write_textEdit_show_msg",
    "user",
    "msg",
    "tester",
    "str",
    "connect_next",
    "on_send_msg",
    "on_connect_enemy",
    "on_start_app",
    "readData",
    "newConnection",
    "addConnection",
    "QTcpSocket*",
    "socket",
    "get_Address",
    "get_ListAddress_Server",
    "check_status_app",
    "connect_confirm"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFunctionAcctionENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   98,    2, 0x06,    1 /* Public */,
       4,    2,  101,    2, 0x06,    3 /* Public */,
       7,    1,  106,    2, 0x06,    6 /* Public */,
       9,    0,  109,    2, 0x06,    8 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      10,    1,  110,    2, 0x0a,    9 /* Public */,
      11,    1,  113,    2, 0x0a,   11 /* Public */,
      12,    0,  116,    2, 0x0a,   13 /* Public */,
      13,    0,  117,    2, 0x0a,   14 /* Public */,
      14,    0,  118,    2, 0x0a,   15 /* Public */,
      15,    1,  119,    2, 0x0a,   16 /* Public */,
      18,    0,  122,    2, 0x0a,   18 /* Public */,
      19,    0,  123,    2, 0x0a,   19 /* Public */,
      20,    0,  124,    2, 0x0a,   20 /* Public */,
      21,    0,  125,    2, 0x0a,   21 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,    5,    6,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,

       0        // eod
};

Q_CONSTINIT const QMetaObject FunctionAcction::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSFunctionAcctionENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFunctionAcctionENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFunctionAcctionENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FunctionAcction, std::true_type>,
        // method 'write_comboBox_list_connection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'write_textEdit_show_msg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'tester'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'connect_next'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_send_msg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_connect_enemy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_start_app'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'readData'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'newConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTcpSocket *, std::false_type>,
        // method 'get_Address'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'get_ListAddress_Server'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'check_status_app'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'connect_confirm'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void FunctionAcction::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FunctionAcction *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->write_comboBox_list_connection((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->write_textEdit_show_msg((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->tester((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->connect_next(); break;
        case 4: _t->on_send_msg((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->on_connect_enemy((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->on_start_app(); break;
        case 7: { bool _r = _t->readData();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: _t->newConnection(); break;
        case 9: _t->addConnection((*reinterpret_cast< std::add_pointer_t<QTcpSocket*>>(_a[1]))); break;
        case 10: _t->get_Address(); break;
        case 11: _t->get_ListAddress_Server(); break;
        case 12: _t->check_status_app(); break;
        case 13: { bool _r = _t->connect_confirm();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QTcpSocket* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FunctionAcction::*)(QString );
            if (_t _q_method = &FunctionAcction::write_comboBox_list_connection; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FunctionAcction::*)(bool , QString );
            if (_t _q_method = &FunctionAcction::write_textEdit_show_msg; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FunctionAcction::*)(QString );
            if (_t _q_method = &FunctionAcction::tester; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FunctionAcction::*)();
            if (_t _q_method = &FunctionAcction::connect_next; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject *FunctionAcction::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FunctionAcction::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFunctionAcctionENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int FunctionAcction::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void FunctionAcction::write_comboBox_list_connection(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FunctionAcction::write_textEdit_show_msg(bool _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void FunctionAcction::tester(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void FunctionAcction::connect_next()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
