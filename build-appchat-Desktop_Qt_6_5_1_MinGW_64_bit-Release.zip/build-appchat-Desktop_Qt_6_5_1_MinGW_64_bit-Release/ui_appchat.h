/********************************************************************************
** Form generated from reading UI file 'appchat.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPCHAT_H
#define UI_APPCHAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AppChat
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_check;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *label;
    QTextEdit *textEdit_recied;
    QLineEdit *lineEdit_Message_Send;
    QPushButton *pushButton_Send;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_IP;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit_Host;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AppChat)
    {
        if (AppChat->objectName().isEmpty())
            AppChat->setObjectName("AppChat");
        AppChat->resize(284, 342);
        centralwidget = new QWidget(AppChat);
        centralwidget->setObjectName("centralwidget");
        pushButton_check = new QPushButton(centralwidget);
        pushButton_check->setObjectName("pushButton_check");
        pushButton_check->setGeometry(QRect(220, 10, 41, 24));
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(12, 42, 258, 246));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName("label");

        gridLayout->addWidget(label, 0, 0, 1, 1);

        textEdit_recied = new QTextEdit(widget);
        textEdit_recied->setObjectName("textEdit_recied");

        gridLayout->addWidget(textEdit_recied, 1, 0, 1, 2);

        lineEdit_Message_Send = new QLineEdit(widget);
        lineEdit_Message_Send->setObjectName("lineEdit_Message_Send");

        gridLayout->addWidget(lineEdit_Message_Send, 2, 0, 1, 1);

        pushButton_Send = new QPushButton(widget);
        pushButton_Send->setObjectName("pushButton_Send");

        gridLayout->addWidget(pushButton_Send, 2, 1, 1, 1);

        widget1 = new QWidget(centralwidget);
        widget1->setObjectName("widget1");
        widget1->setGeometry(QRect(10, 10, 126, 26));
        horizontalLayout = new QHBoxLayout(widget1);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget1);
        label_2->setObjectName("label_2");

        horizontalLayout->addWidget(label_2);

        lineEdit_IP = new QLineEdit(widget1);
        lineEdit_IP->setObjectName("lineEdit_IP");

        horizontalLayout->addWidget(lineEdit_IP);

        widget2 = new QWidget(centralwidget);
        widget2->setObjectName("widget2");
        widget2->setGeometry(QRect(140, 10, 61, 26));
        horizontalLayout_2 = new QHBoxLayout(widget2);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget2);
        label_3->setObjectName("label_3");

        horizontalLayout_2->addWidget(label_3);

        lineEdit_Host = new QLineEdit(widget2);
        lineEdit_Host->setObjectName("lineEdit_Host");

        horizontalLayout_2->addWidget(lineEdit_Host);

        AppChat->setCentralWidget(centralwidget);
        menubar = new QMenuBar(AppChat);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 284, 21));
        AppChat->setMenuBar(menubar);
        statusbar = new QStatusBar(AppChat);
        statusbar->setObjectName("statusbar");
        AppChat->setStatusBar(statusbar);

        retranslateUi(AppChat);

        QMetaObject::connectSlotsByName(AppChat);
    } // setupUi

    void retranslateUi(QMainWindow *AppChat)
    {
        AppChat->setWindowTitle(QCoreApplication::translate("AppChat", "AppChat", nullptr));
        pushButton_check->setText(QCoreApplication::translate("AppChat", "check", nullptr));
        label->setText(QCoreApplication::translate("AppChat", "APP CHAT", nullptr));
        pushButton_Send->setText(QCoreApplication::translate("AppChat", "Send", nullptr));
        label_2->setText(QCoreApplication::translate("AppChat", "IP", nullptr));
        label_3->setText(QCoreApplication::translate("AppChat", "Host", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AppChat: public Ui_AppChat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPCHAT_H
